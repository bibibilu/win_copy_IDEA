import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.mllib.recommendation.{ALS, Rating}
import java.io._
import  java.util.Random

object lu_wang_task1 {

  def main(args: Array[String]): Unit = {
    val start_time = System.currentTimeMillis()

    val conf = new SparkConf().setAppName("INF553_hw3").setMaster("local[*]")
    val sc =  new SparkContext(conf)
    val inputRDD = sc.textFile(args(0))

    val header = inputRDD.first()
    val data = inputRDD.filter(x => x!= header).map(x=> x.split(",")).cache()

    val all_user = data.map(x => (x(0), 1)).reduceByKey((x, y)=>  x+y).keys
    val all_business = data.map(x => (x(1), 1)).reduceByKey((x, y)=>  x+y).keys

    val userNum = all_user.count()
    val businessNum = all_business.count()

    var dic_user = scala.collection.mutable.Map[String,Int]()
    var dic_business = scala.collection.mutable.Map[String,Int]()
    var num = 0
    for(i <- all_user.collect()){
      dic_user += (i -> num)
      num += 1
    }
    num = 0
    for(i <- all_business.collect()){
      dic_business += (i -> num)
      num += 1
    }

    val band = 15
    val row = 2
    var minhashNum = band * row

    var singnature_matrix = scala.collection.mutable.ListBuffer[scala.collection.Map[String, Int]]()
    val p_list = List[Int](71, 277, 691, 1699, 2087, 4211, 6329, 9043, 12613)
    val r = new Random()
    while(minhashNum != 0){
      minhashNum -= 1
      val a = r.nextInt(100)
      val b = r.nextInt(100)
      val p = p_list(r.nextInt(p_list.length))
      val signature = data.map( x=> ( x(1),  (a * dic_user(x(0)) + b) % p )).groupByKey().mapValues(x=> x.toList).map(x => (x._1, x._2.min)).collectAsMap()
      singnature_matrix += signature
    }

    val hash_list = List[Int](1, 23, 133, 231, 591, 891, 1331, 2937, 3473, 5751, 8717, 13321)
    var candidate_pair = scala.collection.mutable.Set[(String,String)]()

    for(bandID <- 0 until(band)){
      val start_row = bandID * row
      var bucket = scala.collection.mutable.Map[Int,scala.collection.mutable.ListBuffer[String]]()

      for (bID <- dic_business){
        var temp = 0
        for(i <- 0 until(row)){
          temp += singnature_matrix(start_row + i)(bID._1) * hash_list(i)
        }
        val hash_value = temp % 16999
        if(!bucket.contains(hash_value)){
          bucket(hash_value) =  scala.collection.mutable.ListBuffer[String](bID._1)
        }else{
          bucket(hash_value) += bID._1
        }
      }

      for(ele <- bucket.values){
        if (ele.toList.length > 1){
          for(i <- ele){
            for(j <- ele){
              if(i != j) {
                val x = List(i,j).sorted
                candidate_pair += Tuple2(x(0), x(1))
              }
            }
          }
        }
      }
    }

    val business_user_dic = data.map(x => (x(1), x(0))).groupByKey().mapValues(x => x.toSet).collectAsMap()

    var final_pair = scala.collection.mutable.ListBuffer[(String,String,String)]()
    for (pair <- candidate_pair){
      var sim = business_user_dic(pair._1).intersect(business_user_dic(pair._2)).size.toFloat / business_user_dic(pair._1).union(business_user_dic(pair._2)).size.toFloat
      if (sim >= 0.5)
        final_pair += Tuple3(pair._1, pair._2, sim.toString)
    }

    val final_pairs = final_pair.toList.sorted
    val output_file = new PrintWriter(args(1))
    //    val output = new PrintWriter("output.csv")

    output_file.write("business_id_1,business_id_2,similarity\n")
    for (i <- final_pairs){
      output_file.write( i._1 + "," + i._2 + "," +i._3 + "\n")
    }
    output_file.close()
    val Duration = (System.currentTimeMillis() - start_time)/1000
    println("Duration: " + Duration.toString)
    println(final_pairs.length)

  }
}
