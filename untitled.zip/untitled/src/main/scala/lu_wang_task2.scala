import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.mllib.recommendation.{ALS, Rating}
import java.io.PrintWriter

object lu_wang_task2 {

  def main(args: Array[String]): Unit = {
    val start_time = System.currentTimeMillis()
    val conf = new SparkConf().setAppName("INF553_hw3").setMaster("local[*]")
    val sc =  new SparkContext(conf)
    val trainRDD = sc.textFile(args(0))
    val valRDD = sc.textFile(args(1))
    val caseNum = args(2).toInt

    val header_train = trainRDD.first()
    val data_train = trainRDD.filter(x=> x!= header_train).map(x => x.split(",")).map(x => (x(0), x(1), x(2))).cache()
    val header_val = valRDD.first()
    val data_val = valRDD.filter(x=> x!= header_val).map(x => x.split(",")).map(x => (x(0), x(1), x(2))).cache()


    if(caseNum == 1) {

      val all_user = data_train.map(x => x._1).union(data_val.map(x => x._1)).distinct().collect()
      val all_business = data_train.map(x => x._2).union(data_val.map(x => x._2)).distinct().collect()

      var dic_user = scala.collection.mutable.Map[String, Int]()
      var dic_business = scala.collection.mutable.Map[String, Int]()
      var user_dic = scala.collection.mutable.Map[Int, String]()
      var business_dic = scala.collection.mutable.Map[Int, String]()
      var num = 0
      for (i <- all_user) {
        dic_user += (i -> num)
        user_dic += (num -> i)
        num += 1
      }
      num = 0
      for (i <- all_business) {
        dic_business += (i -> num)
        business_dic += (num -> i)
        num += 1
      }

      val rating_val = data_val.map(x => (dic_user(x._1), dic_business(x._2)))
      val rating_train = data_train.map(x => (x._1, x._2, x._3) match {case (user, business, rating) => Rating( dic_user(user), dic_business(business),rating.toDouble )})

      val rank = 5
      val numIterations = 10
      val model = ALS.train(rating_train, rank, numIterations, 0.2)

      val predictions = model.predict(rating_val).map{case Rating(user, business, ratings) => ((user_dic(user), business_dic(business)),ratings)}

      val output_file = new PrintWriter(args(3))
      output_file.write("user_id, business_id, prediction\n")
      for(i <- predictions.collect()){
        output_file.write( i._1._1 + "," + i._1._2 + "," +i._2 + "\n")
      }

      val RMSE = data_val.map(x => ((x._1, x._2), x._3.toDouble)).join(predictions).map(x => Math.abs(x._2._1 - x._2._2)).map(x => x*x).mean()
      println(RMSE)

    }


    if (caseNum == 2){
      val get_rating = data_train.map(x => ((x._1, x._2), x._3.toDouble)).collectAsMap()
      val user_average = data_train.map(x=> (x._1, (x._3.toDouble, 1))).reduceByKey((x,y) => (x._1 + y._1, x._2 + y._2)).map(x => (x._1,x._2._1/x._2._2)).collectAsMap()

      val uID_bID_train = data_train.map(x=> (x._1,x._2)).groupByKey().mapValues(x=> x.toSet).collectAsMap()
      val bID_uId_train = data_train.map(x=> (x._2,x._1)).groupByKey().mapValues(x=> x.toSet).collectAsMap()


      val pair_val = data_val.map(x => (x._1, x._2)).collect()

      var prediction_list = scala.collection.mutable.ListBuffer[((String,String),Double)]()
      for (pair <- pair_val){

        if(!uID_bID_train.contains(pair._1)) {
          prediction_list += Tuple2((pair._1, pair._2), 3.0)
        }else if (!bID_uId_train.contains(pair._2)){
          prediction_list += Tuple2((pair._1, pair._2), 3.0)
        }else{
          var user_normalize = scala.collection.mutable.ListBuffer[(Double,Double)]()
          for (other_uID <- bID_uId_train(pair._2)){

            val bID_list_1 = uID_bID_train(pair._1)
            val bID_list_2 = uID_bID_train(other_uID)
            val co_rate = bID_list_1.intersect(bID_list_2)

            val ave_u = user_average(other_uID)
            val ave_a = user_average(pair._1)

            var numerator1 = 0.0
            var d1 = 0.0
            var d2 = 0.0

            for(bID <- co_rate){
              numerator1 += (get_rating((other_uID,bID)) - ave_u) * (get_rating((pair._1,bID)) - ave_a)
              d1 += (get_rating((other_uID,bID)) - ave_u) * (get_rating((other_uID,bID)) - ave_u)
              d2 += (get_rating((pair._1,bID)) - ave_a) * (get_rating((pair._1,bID)) - ave_a)
            }

            val denominator1 = math.sqrt(d1)* math.sqrt(d2)
            var similarity = 0.0
            if (denominator1!=0) {
              similarity = numerator1 / denominator1
            }

            user_normalize += Tuple2(similarity, get_rating((other_uID,pair._2)) - user_average(other_uID))
          }

          var numerator2 = 0.0
          var denominator2 = 0.0

          for(x <- user_normalize){
            numerator2 += x._1 * x._2
            denominator2 += math.abs(x._1)
          }
          var prediction_rating = user_average(pair._1)
          if(denominator2 != 0)
            prediction_rating += numerator2/denominator2

          prediction_list += Tuple2((pair._1, pair._2), prediction_rating)

        }

        val output_file = new PrintWriter(args(3))
        //      val output = new PrintWriter("output.csv")
        output_file.write("user_id, business_id, prediction\n")
        for(i <- prediction_list.toList){
          output_file.write(i._1._1 + "," + i._1._2 + "," + i._2 + "\n")
        }

        val p = sc.parallelize(prediction_list)
        val RMSE = data_val.map(x => ((x._1, x._2), x._3.toDouble)).join(p).map(x => Math.abs(x._2._1 - x._2._2)).map(x => x*x).mean()
        println(RMSE)

      }
    }


    val end_time = System.currentTimeMillis()
    val During = (end_time - start_time) /1000
    println("Duration: " + During)

  }

}
